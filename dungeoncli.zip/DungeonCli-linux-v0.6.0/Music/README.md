NOTE: These are NOT my songs, I don't own any rights to them, the original
song author was 'Ben Prunty' which was used in the 2012 game, 'FTL: Faster Than
Light'

I will replace these songs once I get my own ones, these are just placeholders.


**Made by Ben Prunty:**

federation.mp3,
milkywayBattle.mp3
rockmenBattle.mp3

**Made by Sine:**
These songs were made specifically for this game,

quest.ogg
gameOver.mp3

**Made by AsianPotato77:**
These songs were also made specifically for this game,
Ambient_fight_1.ogg
interstellar_space_dryer_2.ogg
bossBattle.ogg
intro.ogg
